<template>
<div>
	<h1>mpvue is good</h1>
	<Todolist></Todolist>
</div>
</template>

<script>
import Todolist from '@/components/Todolist'

export default {
	components: {
		Todolist
	}
}
</script>

<style>
h1 {
	color: read
}
</style>
